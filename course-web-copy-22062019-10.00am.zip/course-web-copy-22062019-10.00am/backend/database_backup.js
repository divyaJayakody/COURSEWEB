const db_courses =
    [
        /* 1 */
{
    "_id" : ObjectId("5d097e35d7f11294d147bfb2"),
    "course_id" : "005",
    "course_name" : "AF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "20/05/19"
}
,
/* 2 */
{
    "_id" : ObjectId("5d097e35d7f11294d147bfb3"),
    "course_id" : "007",
    "course_name" : "SHA",
    "course_instructor" : "Divya",
    "course_approved_Date" : "22/05/19"
}
,
/* 3 */
{
    "_id" : ObjectId("5d097e35d7f11294d147bfb4"),
    "course_id" : "008",
    "course_name" : "FFA",
    "course_instructor" : "Divya",
    "course_approved_Date" : "21/05/19"
}
,
/* 4 */
{
    "_id" : ObjectId("5d097e35d7f11294d147bfb5"),
    "course_id" : "011",
    "course_name" : "AAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "19/05/19"
}
,
/* 5 */
{
    "_id" : ObjectId("5d0afa457802671594f6588b"),
    "course_id" : "033",
    "course_name" : "PAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 8:45:15 AM",
    "__v" : 0
}
,
/* 6 */
{
    "_id" : ObjectId("5d0aff2555f45d4d9c89f7a1"),
    "course_id" : "033",
    "course_name" : "PAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 9:05:55 AM",
    "__v" : 0
}
,
/* 7 */
{
    "_id" : ObjectId("5d0affb33d921340803d1c90"),
    "course_id" : "033",
    "course_name" : "PAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 9:08:27 AM",
    "__v" : 0
}
,
/* 8 */
{
    "_id" : ObjectId("5d0b00bf3d921340803d1c92"),
    "course_id" : "034",
    "course_name" : "GAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 9:12:55 AM",
    "__v" : 0
}
,
/* 9 */
{
    "_id" : ObjectId("5d0b01193d921340803d1c94"),
    "course_id" : "034",
    "course_name" : "GAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 9:14:25 AM",
    "__v" : 0
}
,
/* 10 */
{
    "_id" : ObjectId("5d0b01c53d921340803d1c96"),
    "course_id" : "035",
    "course_name" : "RAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 9:17:17 AM",
    "__v" : 0
}
,
/* 11 */
{
    "_id" : ObjectId("5d0b03423d921340803d1c98"),
    "course_id" : "037",
    "course_name" : "BAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 9:23:38 AM",
    "__v" : 0
}
,
/* 12 */
{
    "_id" : ObjectId("5d0b05d744139d4f58882af2"),
    "course_id" : "037",
    "course_name" : "BAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 9:34:38 AM",
    "__v" : 0
}
,
/* 13 */
{
    "_id" : ObjectId("5d0b061d35a7c15bf8e62a64"),
    "course_id" : "037",
    "course_name" : "BAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 9:35:48 AM",
    "__v" : 0
}
,
/* 14 */
{
    "_id" : ObjectId("5d0b0705de71fc51001bae33"),
    "course_id" : "039",
    "course_name" : "YAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 9:39:41 AM",
    "__v" : 0
}
,
/* 15 */
{
    "_id" : ObjectId("5d0b083177cdd74a84843514"),
    "course_id" : "039",
    "course_name" : "YAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/20/2019 9:44:41 AM",
    "__v" : 0
}
,
/* 16 */
{
    "_id" : ObjectId("5d0bdb2890685805ec39dddf"),
    "course_id" : "038",
    "course_name" : "CAF",
    "course_instructor" : "Divya",
    "course_approved_Date" : "6/21/2019 12:44:48 AM",
    "__v" : 0
}

];

/**
 *{
    "_id" : ObjectId("5d0bec0440e2acf81ee76301"),
    "code" : "005",
    "name" : "AF",
    "semester" : "1st ,2019",
    "inchrage" : "Divya",
    "credits" : "6"
}


{
    "_id" : ObjectId("5d0bec3840e2acf81ee76323"),
    "code" : "006",
    "name" : "DS",
    "semester" : "1st ,2019",
    "inchrage" : "Samadhi",
    "credits" : "6"
}


{
    "_id" : ObjectId("5d0bec5d40e2acf81ee76336"),
    "code" : "007",
    "name" : "SEPQM",
    "semester" : "1st ,2019",
    "inchrage" : "Wendy",
    "credits" : "6"
}

{
    "_id" : ObjectId("5d0bec7840e2acf81ee76342"),
    "code" : "008",
    "name" : "SA",
    "semester" : "1st ,2019",
    "inchrage" : "Yasiru",
    "credits" : "6"
}
 */
