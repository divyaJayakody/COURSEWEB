import React,{Component} from 'react';
import axios from 'axios';

export default class EditBook extends Component {

    constructor(props){
        super(props);


        this.onChangeBookName = this.onChangeBookName.bind(this);
        this.onChangeBookAuthor = this.onChangeBookAuthor.bind(this);
        this.onChangeBookPublisher= this.onChangeBookPublisher.bind(this);
        this.onChangeBookGenre = this.onChangeBookGenre.bind(this);
        this.onChangeBookPrice = this.onChangeBookPrice.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state={
            book_name:'',
            book_author:'',
            book_publisher:'',
            book_genre:'',
            book_price:'',

        }

    }

    componentDidMount(){
        axios.get('http://localhost:4000/books/'+this.props.match.params.id)
            .then(res=>{
                this.setState({
                    books_name:res.data.book_name,
                    books_author:res.data.book_author,
                    books_publisher:res.data.book_publisher,
                    books_genre:res.data.book_genre,
                    books_price:res.data.book_price,

                })
            })
            .catch(function(error){
                console.log(error);
            })
    }

    onChangeBookName(e){
        this.setState({

            book_name:e.target.value
        });
    }
    onChangeBookAuthor(e){
        this.setState({

            book_author:e.target.value
        });
    }
    onChangeBookPublisher(e){
        this.setState({

            book_publisher:e.target.value
        });
    }
    onChangeBookGenre(e){
        this.setState({

            book_genre:e.target.value
        });
    }
    onChangeBookPrice(e){
        this.setState({

            book_price:e.target.value
        });
    }



    onSubmit(e){

        e.preventDefault();

        const bookObj = {
            book_name:this.state.book_name,
            book_author:this.state.book_author,
            book_publisher:this.state.book_publisher,
            book_genre:this.state.book_genre,
            book_price:this.state.book_price

        };

        axios.post('http://localhost:4000/books/update/'+this.props.match.params.id,bookObj)
            .then(res=>console.log(res.data));

        this.props.history.push('/');
    }

    render(){
        return(
            <div style={{marginTop:10}}>
                <h3>Edit Book</h3>
                <form onSubmit={this.onSubmit}>

                    <div className="form-group">
                        <label>Name :</label>
                        <input type ="text"
                               className="form-control"
                               value={this.state.book_name}
                               onChange={this.onChangeBookName}
                        />
                    </div>
                    <div className="form-group">
                        <label>Author :</label>
                        <input type ="text"
                               className="form-control"
                               value={this.state.book_author}
                               onChange={this.onChangeBookAuthor}
                        />
                    </div>
                    <div className="form-group">
                        <label>Publisher :</label>
                        <input type ="text"
                               className="form-control"
                               value={this.state.book_publisher}
                               onChange={this.onChangeBookPublisher}
                        />
                    </div>
                    <div className="form-group">
                        <label>Genre :</label>
                        <input type ="text"
                               className="form-control"
                               value={this.state.book_genre}
                               onChange={this.onChangeBookGenre}
                        />
                    </div>
                    <div className="form-group">
                        <label>Price :</label>
                        <input type ="text"
                               className="form-control"
                               value={this.state.book_price}
                               onChange={this.onChangeBookPrice}
                        />
                    </div>
                    <div className="form-group">
                        <input type="submit" value = "Update Book" className="btn btn-primary" />
                    </div>
                </form>
            </div>
        )
    }
}